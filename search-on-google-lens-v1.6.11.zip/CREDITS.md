# Credits

## Font Awesome
Font Awesome content is used for some of the icons.
<br>
© Fonticons, Inc.
<br>
Repository: https://github.com/FortAwesome/Font-Awesome
<br>
License: https://fontawesome.com/license/free , https://creativecommons.org/licenses/by/4.0/
