# Search on Google Lens
Add-on that enables Google Lens to search for images on websites

## What is this ?
This add-on allows you to easily search for images on websites with Google Lens.

## How to use
Right-click on an image on a website and click "Search on Google Lens" from the context menu.

Google Lens will then search for the image.

## Contributors
<a href="https://github.com/typeling1578/Search-on-Google-Lens/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=typeling1578/Search-on-Google-Lens" />
</a>
